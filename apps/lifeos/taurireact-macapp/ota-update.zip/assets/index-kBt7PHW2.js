import{i as o}from"./index-Deg5JZyZ.js";async function p(i,n){await o("plugin:shell|open",{path:i,with:n})}export{p as open};
