import{i as o}from"./index-Dd4i2u7s.js";async function p(i,n){await o("plugin:shell|open",{path:i,with:n})}export{p as open};
